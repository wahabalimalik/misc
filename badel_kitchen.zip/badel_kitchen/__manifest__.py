{
    'name': "Badel Kitchen",
    'version': '1.0',
    'depends': ['base'],
    'author': "Ahmed Hassan",
    'category': 'Manufacturing',
    'description': """
    This Module is used to Manage the Workflow of the Badel Kitchen.Develop by Ahmed (skooperss@gmail.com)
    """,
    'data': [
        'views/data_views.xml',
    ],
}