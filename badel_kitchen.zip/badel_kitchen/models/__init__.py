# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import appointment
import contact_form
import sale_badel
import desgin
import production